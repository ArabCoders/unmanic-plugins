# Custom Audio Encoder

Use it to convert any non-matching codec to your liking.

plugin for [Unmanic](https://github.com/Unmanic)

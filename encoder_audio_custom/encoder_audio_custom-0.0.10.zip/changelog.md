**<span style="color:#56adda">0.0.10</span>**

- Handle Each stream channel/channel_layout.

**<span style="color:#56adda">0.0.9</span>**

- Better handling channels and channel_layout.

**<span style="color:#56adda">0.0.8</span>**

- Handle eAC3 channel_layout (unknown) condition as 5.1(side) if converting to opus

**<span style="color:#56adda">0.0.7</span>**

- Config option text update.

**<span style="color:#56adda">0.0.6</span>**

- Made the workaround for libopus optional and configurable.

**<span style="color:#56adda">0.0.5</span>**

- Opus codec can't do 5.1(side). workaround.

**<span style="color:#56adda">0.0.2</span>**

- text updates.

**<span style="color:#56adda">0.0.1</span>**

- initial version

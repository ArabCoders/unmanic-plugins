
You can use this plugin to convert any audio stream that does not match your required codec.

# Configurable options

### <span style="color:magenta">Does the stream use this codec?</span>
- opus

------------

if not found it will convert the stream to use whatever provided in the next option.

------------

### <span style="color:magenta">If not convert to this stream.</span>
- libopus

------------

### <span style="color:magenta">Set default audio bitrate</span>
- 96

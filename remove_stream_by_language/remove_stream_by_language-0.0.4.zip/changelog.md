
**<span style="color:#56adda">0.0.4</span>**
- Added check to not remove audio stream if there is only one stream.

**<span style="color:#56adda">0.0.3</span>**
- Added the ability to remove audio/subtitle by title.

**<span style="color:#56adda">0.0.1</span>**
- Initial version

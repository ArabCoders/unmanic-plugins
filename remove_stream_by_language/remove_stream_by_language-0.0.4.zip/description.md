
Enter a comma separated list of language codes to search for during library scans and new file event triggers.

Any video files with an audio or subtitle streams having tags that match these language codes listed here will be removed from their files.

---

#### Examples:

###### <span style="color:magenta">Remove Italian and French streams</span>
```
ita,fra
```
